package PDE_NoVectors.Model;

public class Constants {

	
	/**
	 * Class which contains the constants required for an MD system
	 * @author s0831683
	 *
	 */
		public static double epsilon = 1.0;
		public static double chargeScale = 1;

}
